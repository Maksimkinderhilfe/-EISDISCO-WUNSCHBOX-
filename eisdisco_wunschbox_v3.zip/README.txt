EISDISCO WUNSCHBOX 3.0

Startbildschirm:
- 🎵 BESUCHER
- 🖥️ DJ

DJ-Passwort:
Das Passwort wird SERVERSEITIG über ADMIN_PASSWORD gesetzt.
Beispiel: ADMIN_PASSWORD=DJBREEZE

WICHTIG:
Nicht das Passwort in app.js eintragen. Auf einem echten Hosting-Dienst
als geheime Umgebungsvariable setzen.

START:
npm install
ADMIN_PASSWORD="DJBREEZE" node server.js

Spotify:
SPOTIFY_TOKEN muss für die Suchfunktion gesetzt werden.
Für die echte Veröffentlichung sollte Spotify OAuth/PKCE sauber eingerichtet
werden, statt einen persönlichen Token fest einzubauen.

SPAM:
Maximal 3 offene Wünsche pro IP innerhalb von 24 Stunden.
Das ist ein einfacher Schutz und nicht perfekt, besonders in öffentlichen WLANs.

SPEICHER:
wishes.json wird serverseitig gespeichert. Für echtes Hosting sollte ein
persistenter Datenspeicher bzw. eine Datenbank verwendet werden.

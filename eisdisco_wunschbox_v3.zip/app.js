let adminToken=localStorage.getItem("djToken")||"";
const $=s=>document.querySelector(s);
async function api(url,opt={}){const r=await fetch(url,{...opt,headers:{"Content-Type":"application/json",...(opt.headers||{})}});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||"Fehler");return d}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function show(id){["start","visitor","djLogin","adminPanel"].forEach(x=>$( "#"+x).hidden=x!==id)}

$("#visitorBtn").onclick=()=>{show("visitor");loadWishes()};
$("#djBtn").onclick=()=>show("djLogin");
document.querySelectorAll(".back").forEach(b=>b.onclick=()=>show("start"));

$("#searchForm").addEventListener("submit",async e=>{
 e.preventDefault();const title=$("#title").value.trim(),artist=$("#artist").value.trim();$("#results").innerHTML="<p>🔎 Suche...</p>";
 try{const d=await api(`/api/search?title=${encodeURIComponent(title)}&artist=${encodeURIComponent(artist)}`);
 $("#results").innerHTML=d.tracks.length?d.tracks.map(t=>`<div class="result"><div class="resultInfo">${t.image?`<img src="${t.image}" alt="">`:""}<div><strong>${esc(t.title)}</strong><small>${esc(t.artist)} · ${esc(t.album)}</small></div></div><button onclick='wish(${JSON.stringify(t).replace(/'/g,"&#39;")})'>🎵 Wünschen</button></div>`).join(""):"<p>Kein passender Treffer.</p>"
 }catch(e){$("#results").innerHTML=`<p>❌ ${esc(e.message)}</p>`}
});
async function wish(t){try{await api("/api/wishes",{method:"POST",body:JSON.stringify({title:t.title,artist:t.artist,spotifyId:t.id})});$("#msg").textContent="✅ Wunsch gespeichert!";loadWishes()}catch(e){$("#msg").textContent="❌ "+e.message}}
async function loadWishes(){try{const w=await api("/api/wishes");render($("#publicWishes"),w,false);if(!$("#adminPanel").hidden)render($("#adminWishes"),w,true)}catch{}}
function render(box,w,admin){box.innerHTML=w.length?w.map((x,i)=>`<article class="wish"><div><strong>${i+1}. ${esc(x.title)}</strong><small>${esc(x.artist)} · 👥 ${x.votes||1}</small></div>${admin?`<div class="actions"><button class="ok" onclick="adminAction('${x.id}','done')">✅ Erledigt</button><button class="bad" onclick="adminAction('${x.id}','remove')">❌ Ablehnen</button></div>`:""}</article>`).join(""):"<p class='muted'>Noch keine Wünsche.</p>"}

$("#loginBtn").onclick=async()=>{try{const d=await api("/api/admin/login",{method:"POST",body:JSON.stringify({password:$("#djPassword").value})});adminToken=d.token;localStorage.setItem("djToken",adminToken);$("#djPassword").value="";show("adminPanel");loadWishes()}catch(e){$("#loginMsg").textContent="❌ "+e.message}};
async function adminAction(id,action){try{await api(`/api/admin/wishes/${id}`,{method:"PATCH",headers:{"Authorization":"Bearer "+adminToken},body:JSON.stringify({action})});loadWishes()}catch(e){alert(e.message)}}
$("#logoutBtn").onclick=()=>{adminToken="";localStorage.removeItem("djToken");show("start")};
loadWishes();setInterval(loadWishes,3000);
if(adminToken){/* Token bleibt gespeichert, Startscreen bleibt trotzdem sichtbar. */}

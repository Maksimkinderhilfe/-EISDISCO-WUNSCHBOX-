const express=require("express"),path=require("path"),crypto=require("crypto"),fs=require("fs");
const app=express(),PORT=process.env.PORT||8080,ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"eisdisco-demo",SPOTIFY_TOKEN=process.env.SPOTIFY_TOKEN||"";
app.use(express.json());app.use(express.static(__dirname));
const DB=path.join(__dirname,"wishes.json");
let wishes=fs.existsSync(DB)?JSON.parse(fs.readFileSync(DB,"utf8")):[];
function save(){fs.writeFileSync(DB,JSON.stringify(wishes,null,2))}
const sessions=new Set();
function auth(req,res,next){const t=(req.headers.authorization||"").replace("Bearer ","");if(!sessions.has(t))return res.status(401).json({error:"Nicht angemeldet"});next()}
app.get("/api/search",async(req,res)=>{
 if(!SPOTIFY_TOKEN)return res.status(503).json({error:"Spotify ist noch nicht eingerichtet. Setze SPOTIFY_TOKEN auf dem Server."});
 const q=`track:${req.query.title||""} artist:${req.query.artist||""}`;
 try{const r=await fetch(`https://api.spotify.com/v1/search?type=track&limit=8&market=DE&q=${encodeURIComponent(q)}`,{headers:{Authorization:`Bearer ${SPOTIFY_TOKEN}`}});
 const d=await r.json();if(!r.ok)return res.status(r.status).json({error:d.error?.message||"Spotify-Fehler"});
 res.json({tracks:(d.tracks?.items||[]).map(t=>({id:t.id,title:t.name,artist:t.artists.map(a=>a.name).join(", "),album:t.album.name,image:t.album.images?.[0]?.url||""}))})}catch(e){res.status(500).json({error:"Spotify-Suche fehlgeschlagen"})}
});
app.get("/api/wishes",(req,res)=>res.json(wishes.filter(w=>w.status==="pending")));
app.post("/api/wishes",(req,res)=>{
 const ip=(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"unknown").split(",")[0].trim();
 const now=Date.now(); const recent=wishes.filter(w=>w.ip===ip&&w.createdAt>now-24*60*60*1000&&w.status==="pending");
 if(recent.length>=3)return res.status(429).json({error:"Du hast bereits 3 offene Wünsche. Warte, bis einer erledigt wurde."});
 const {title,artist,spotifyId}=req.body;if(!title||!artist||!spotifyId)return res.status(400).json({error:"Songtitel, Interpret und Spotify-Treffer erforderlich."});
 const duplicate=wishes.find(w=>w.spotifyId===spotifyId&&w.status==="pending");if(duplicate){duplicate.votes=(duplicate.votes||1)+1;save();return res.json(duplicate)}
 const w={id:crypto.randomUUID(),title:String(title).slice(0,120),artist:String(artist).slice(0,120),spotifyId,ip,createdAt:now,status:"pending",votes:1};
 wishes.push(w);save();res.status(201).json(w)
});
app.post("/api/admin/login",(req,res)=>{if(req.body.password!==ADMIN_PASSWORD)return res.status(401).json({error:"Falsches Passwort"});const token=crypto.randomBytes(32).toString("hex");sessions.add(token);res.json({token})});
app.patch("/api/admin/wishes/:id",auth,(req,res)=>{const w=wishes.find(x=>x.id===req.params.id);if(!w)return res.status(404).json({error:"Nicht gefunden"});if(!["done","remove"].includes(req.body.action))return res.status(400).json({error:"Ungültige Aktion"});w.status=req.body.action;save();res.json({ok:true})});
app.get("/api/health",(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`Wunschbox läuft auf Port ${PORT}`));
